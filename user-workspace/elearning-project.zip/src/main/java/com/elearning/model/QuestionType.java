package com.elearning.model;

public enum QuestionType {
    MULTIPLE_CHOICE,
    TRUE_FALSE,
    SHORT_ANSWER,
    ESSAY,
    MATCHING
}
